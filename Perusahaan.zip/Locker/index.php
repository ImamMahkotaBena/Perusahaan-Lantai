<!doctype html>
<html lang="en">
<head>
	<title>Locker App</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700&display=swap" rel="stylesheet">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

	<link rel="stylesheet" href="css/style.css">

</head>

<body>
	<section class="ftco-section">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-md-6 text-center mb-5">
					<h2 class="heading-section">Locker</h2>
				</div>
			</div>
			<div class="row justify-content-center">
				<div class="col-md-7 col-lg-5">
					<div class="login-wrap p-4 p-md-5">
						<form action="#" class="login-form">
							<div class="form-group">
								<input type="text" class="form-control rounded-left" placeholder="Nomor Loker" id="loker" onchange="search(this.value)" required>
							</div>
							<div class="form-group">
								<input type="text" class="form-control rounded-left" placeholder="Nomor Lantai" id="lantai" disabled>
							</div>
							<!-- <div class="form-group">
								<button type="submit" onclick="search()" class="form-control btn btn-primary rounded submit px-3">Login</button>
							</div> -->
						</form>
					</div>
				</div>
			</div>
		</div>
	</section>

	<script src="js/jquery.min.js"></script>
	<script src="js/popper.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/main.js"></script>

	<script>
		function search(val) {
			var lantai = val % 18
			var bagi = val / 18
			var rounded = Math.floor(bagi)

			if (lantai > 0 && lantai <= 5) {
				if (rounded == 0) {
					var hasil = rounded * 1 + 1
				} else {
					var hasil = rounded  * 3 + 1
				}
			} else if (lantai >= 6 && lantai <= 11) {
				if (rounded == 0) {
					var hasil = rounded * 3 + 2
				} else {
					var hasil = rounded * 3 + 2
				}
			} else if (lantai == 0 || lantai <= 17) {
				if (lantai == 0) {
					var hasil = (rounded - 1) * 3 + 3
				} else {
					var hasil = rounded * 3 + 3
				}
			}

			var x = document.getElementById('lantai')
			x.value = hasil
		}
	</script>

</body>
</html>